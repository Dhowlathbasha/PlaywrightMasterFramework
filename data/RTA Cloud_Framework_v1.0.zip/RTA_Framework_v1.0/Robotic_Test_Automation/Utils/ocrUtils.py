import os
import pathlib
from datetime import datetime
import cv2
from pytesseract import pytesseract, Output

from Utils import Cloud_Components
Cloud_OCR = None
Cloud_OCR = Cloud_Components.ocr_CloudComponents()
Path = str(pathlib.Path().absolute())
Image_Path = Path+r'/Resources/Images'

def Image_Validation_Method(Textraction_Engine,cameraPort):

    textraction_engine_type = Textraction_Engine
    now1 = datetime.now()
    print(now1.strftime("%H:%M:%S"))
    TebotImage_getimage_customport(cameraPort)
    now = datetime.now()
    print(now.strftime("%H:%M:%S"))
    imagepath = Image_Path+'/image.jpg'
    try:
        #TebotImage_getimage_method()   ##ImageCapture
        #Crop_Image_Method(x1, x2, y1, y2) ##Image Crop for ROI
        if textraction_engine_type.lower() == 'local':
            return Image_Extraction_Pytesseract()
        elif textraction_engine_type.lower() == 'azure':
            return Cloud_OCR.analyze_read(Image_Path+"/image.jpg")
        elif textraction_engine_type.lower() == 'google':
            return Cloud_OCR.detect_text(Image_Path+"/image.jpg")
        else:
            return Cloud_OCR.text_extraction('0', Image_Path+"/image.jpg")  ##Apply Textraction for local image
    except IOError:
        #logger.error("Could not access the file ")
        return "Could not access the camera ! please check the connection"
    except AttributeError:
        print(" Attribute Error occured... trying to reconnect..........")
        #logger.error("  Attribute Error occured due to invalid input or connection issue or undefined variable input" + "\n")
        return "Check the  connection "
    except TypeError as e:
        print("exception occured" + str(e.args))
        #logger.error("  Attribute Error occured due to invalid input or connection issue or undefined variable input" + "\n")
        return "Type error occured  check the connection"

def textValidation(actualText, expectedText):
    if ' ' in expectedText:
        expectedText = expectedText.split(' ')
    else:
        expectedText = [expectedText]
    flag = 'PASS'
    temp = ''
    textpresent = 0
    print('expected text', expectedText)
    for i in range(len(expectedText)):
        if str(expectedText[i]).lower() in str(actualText).lower():
            flag = 'PASS'
            textpresent = textpresent + 1
            print(str(expectedText[i]))
        else:
            print(str(expectedText[i]), " is not in the actual text")
            flag = str(i)
            temp = 'FAIL'
    outputpercentage = (textpresent/len(expectedText)) * 100
    print(outputpercentage)
    textOutputAccuracy = []
    textOutputAccuracy.append(outputpercentage)
    if temp == 'FAIL':
        return temp,textOutputAccuracy
    else:
        return flag,textOutputAccuracy

def TebotImage_getimage_customport(cameraPort):

    #from Python.GrabImage import GrabImage
    #GrabImage.work_thread()
    #GrabImage.MV_CC_GetImageBuffer

    try:
        isExist = os.path.exists(Image_Path)
        if not isExist:
            # Create a new directory because it does not exist
            os.makedirs(Image_Path)
            print("The new directory is created!")
        cap = cv2.VideoCapture(int(cameraPort),cv2.CAP_DSHOW)
        cap.set(3,1920)
        cap.set(4,1080)


        #cap.set(cv2.CAP_PROP_FRAME_WIDTH,1920)
        #cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 1080)
        for i in range(5):
            ret, frame = cap.read()
        #cv2.imshow('frame', frame)
        cv2.imwrite(Image_Path+'/image.jpg', frame)
        cap.release()
        print("image captured")


        #cv2.destroyAllWindows()
        #return send_file(path, mimetype='image/png')
        return "Image Captured"
    except IOError:
        #logger.error("Could not access the file ")
        return "Could not access the camera ! please check the connection"
    except AttributeError:
        print(" Attribute Error occured... trying to reconnect..........")
        #logger.error("  Attribute Error occured due to invalid input or connection issue or undefined variable input" + "\n")
        return "Check the  connection "
    except TypeError as e:
        print("exception occured" + str(e.args))
        #logger.error("  Attribute Error occured due to invalid input or connection issue or undefined variable input" + "\n")
        return "Type error occured  check the connection"



#from translate import Translator
def Image_Extraction_Pytesseract():
    image = cv2.imread(Image_Path+"/image.jpg")
    gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    options = "-l {} psm {}".format("jpn", "psm")

    text = pytesseract.image_to_string(gray_image,config=options, output_type=Output.DICT)
    smp_text = text['text'].rstrip('\n\x0c')
    # translator = Translator(from_lang="japanese", to_lang="english")
    # translation = translator.translate(smp_text)
    # print("Translated : ")
    # print(translation)
    # print("original : ")
    print(text['text'].rstrip('\n\x0c'))
    if text['text'].rstrip('\n\x0c')== None:
        text = pytesseract.image_to_string(image, output_type=Output.DICT)

        print(text['text'].rstrip('\n\x0c'))

    return text['text'].rstrip('\n\x0c')


