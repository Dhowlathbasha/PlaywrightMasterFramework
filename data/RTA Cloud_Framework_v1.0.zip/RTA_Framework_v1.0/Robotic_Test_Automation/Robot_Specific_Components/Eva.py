import time

import configobj
from evasdk import Eva

from Framework_Components import GetData
from Framework_Components.GetData import *

eva = None
Eva_session_flag=None
#eva = Eva(host_ip,token)
ERROR_CLEAR_RESPONSE = 'Error Cleared'


def run_Eva(Toolpath):
    global eva
    print("Executing Toolpath : "+ Toolpath)
    time.sleep(2)
    # Arm_Toolpath_name = Toolpath
    # Arm_IP = GetData.get_configuration("Heading","Eva_IP")
    # User_Token = GetData.get_configuration("Eva","Eva_Token")
    # Eva_Init(Arm_IP,User_Token)
    # if RoboArm_Control_Reset_Errors_Method() == ERROR_CLEAR_RESPONSE:
    #      print("There was Error and Its Cleared! Executing the Robot")
    #      return Eva_Run_Method(Arm_Toolpath_name)
    # else:
    #      print("No error occured. So Executing the Robot")
    #      return Eva_Run_Method(Arm_Toolpath_name)


def Eva_Init(Arm_IP,API_Token):
    global eva
    #eva = None
    global Eva_session_flag
    try:
        print(eva)
        eva = Eva(Arm_IP, API_Token)
        #eva.lock(wait=True,timeout=10)
        #Eva_session_flag=1
        #session_thread = threading.Thread(target=Eva_session_method)
        #session_thread.start()
        print("Eva Init")
        return "Eva Robot Init Successfull"
    except Exception as e:
        print(e)
        return str(e)

def RoboArm_Control_Reset_Errors_Method():
    global eva
    try:
        with eva.lock():
            eva.control_reset_errors()
        return "Error Cleared"
    except AttributeError:
        return "Please Initialize the Robot with IP and API Token"
    except Exception as e:
        print(e)
        return e

def Eva_Run_Method(toolpath):
    global eva
    if '-' in toolpath:
        toolpath = toolpath.split('-')
        #print(" splited code :"+str(toolpath))
    else:
        toolpath = [toolpath]
    #print(len(toolpath))
    for toolname in range(len(toolpath)):
        try:
            tool_path_ID = get_tool_path_ID(toolpath[toolname])
            print("tool path id found "+str(tool_path_ID))
            Tool_path_data = eva.toolpaths_retrieve(int(tool_path_ID))
            #print(json.dumps(Tool_path_data["toolpath"]))
            with eva.lock():
                eva.toolpaths_use(Tool_path_data["toolpath"])
                eva.control_home()
                eva.control_run(loop=1, mode='teach')

        except TypeError:                         ####if wrong name is requested it will skip the name
            print("Name is not available")
            return "Type Error Occurred"
        except IOError:
            #return "IO Error Occurred"
            return "Robot is running"
        except AttributeError:
            return "Attribute Error Occurred"

        except Exception as e:
            print("Exception occurred"+str(e))
            return str(e)
    #eva.lock()
    #del eva

    return f"Cobot Action Completed for : {toolpath}"

def get_tool_path_ID(toolpath_name):
    global eva
    #print("tool path name for find ID"+str(toolpath_name))
    toolpaths = eva.toolpaths_list()
    #print("lenghth of list"+str(len(toolpaths)))
    for toolname in range(len(toolpaths)):
        #print(toolname)
        #print(str(toolpaths[toolname]['name']))
        if toolpaths[toolname]['name'] == toolpath_name :
            #print("id found")
            #print(str(toolpaths[toolname]['name']))
            #print(toolpaths[toolname]['id'])
            return toolpaths[toolname]['id']
        #elif toolname ==len(toolpaths):
            #return "Invalid ToolPath Name !! Please Check the List"
        else:
            pass
    return "Invalid ToolPath Name !! Please Check the Input Toolpath List"
