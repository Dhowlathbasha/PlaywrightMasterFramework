from Framework_Components import Reports
from Framework_Components.GetData import *
from Robot_Specific_Components.Eva import run_Eva
from Robot_Specific_Components.GoFa import run_GoFa
from Utils.ocrUtils import Image_Validation_Method, textValidation
from Business_Components import eva_Test

def Infotainment_Map():
    Home_toolpath = run_Eva(eva_Test.Maps)
    print("\topening MAP")
    Reports.AddStepDetailsToTestcaseHTML("Testing Map App ", eva_Test.Maps, "Map Opened Sucessfully",
                                         "Map Opened Sucessfully", "PASS", "NA")
    Map_Search = run_Eva(eva_Test.SearchBox)
    print("\tClicking on Serach Box")
    direction = run_Eva(eva_Test.Click_direction)
    print("\tClicking on direction Button")
    Reports.AddStepDetailsToTestcaseHTML("Testing Map App ", eva_Test.Maps, "Direction Button clicked Sucessfully",
                                         "Direction Button clicked Sucessfully", "PASS", "NA")
    Startlocation = run_Eva(eva_Test.startLocation)
    print("\tClicking on start Direction")
    Reports.AddStepDetailsToTestcaseHTML("Testing Map App ", eva_Test.Maps, "Start Location Button clicked Sucessfully",
                                         "Start Location Button clicked Sucessfully", "PASS", "NA")
    CloseMap = run_Eva(eva_Test.CloseMap)
    print("\tClosing Map Application")

def Infotainment_call():
    mobileApp = run_Eva(eva_Test.mobileApp)
    print("\tOpening Mobile Application")
    mobileApp = run_Eva(eva_Test.dialicon)
    print("\tClicking on Recently Dialed Number")
    mobileApp = run_Eva(eva_Test.callbutton)
    print("\tClicking on call button")

def InfotainmentMusic():
    musicApp = run_Eva(eva_Test.musicApp)
    print("\tOpening Music Application ")
    playSong = run_Eva(eva_Test.playSong)
    print("\tPlaying First Song")
    CloseMusic = run_Eva(eva_Test.CloseMusic)
    print("\tClosing Music Application")
