from AutomationLibraries.Api import *
from Framework_Components.GetData import *
from Framework_Components import Reports, GetData
from AutomationLibraries import Api

def postcall():
    url = 'http://192.168.155.137:5000/TebotAPI/ImageValidation'
    data = '{"Textraction_Engine": "ocal","camera_port": "0"}'
    headers = {'content-type': 'application/json'}
    response = Api.getresponse(url,"POST",data,headers,200)
    responsecontent = response.decode()
    print(responsecontent)
    Expectedtext = GetData.get_data("ExpectedData")
    #ResponseValidation("post call",url,responsecontent,"TAG","text","Sample","contains")
    ResponseValidation("post call", url, responsecontent, "TAG", "text", Expectedtext, "contains")
    #print(response)

def getcall():
    url = 'https://dummyjson.com/'
    headers = {'content-type': 'application/json; charset=UTF-8'}
    response = Api.getresponse(url,"GET",headers,200)
    responsecontent = response.content.decode()
    print(responsecontent)
    Expectedtext = GetData.get_data("ExpectedData")
    ResponseValidation("get call", url, responsecontent,"Body", "", Expectedtext, "contains")