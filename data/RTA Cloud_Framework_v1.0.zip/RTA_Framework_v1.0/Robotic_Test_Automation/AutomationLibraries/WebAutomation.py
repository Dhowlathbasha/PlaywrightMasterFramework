import time
from os.path import abspath
from selenium import webdriver
from selenium.webdriver.common.by import By

from Framework_Components import GetData

global driver

def driveraction(action):
    global driver
    if action.lower() == 'close':
        driver.close()
        driver.quit()
        driver = None
        #driver.delete_all_cookies()
        #driver.stop_client()

    else:

        # browser = 'chrome'
        driver = webdriver
        if action.lower() == 'chrome':
            driver = driver.Chrome(executable_path=abspath("Resources/AutomationDrivers/chromedriver.exes"))
            print('chrome driver initialised...')

        if action.lower() == 'firefox':
            driver = driver.Firefox()
            pass
        if action.lower() == 'edge':
            driver = driver.Edge("path to edgedriver.exe")
            pass


def takescreen(imagePath):
    global driver
    #driver.get_full_page_screenshot_as_file(imagePath)
    #driver.screenshot(imagePath)
    driver.save_screenshot(imagePath)


# def openBrowser1():
#    # URL = GetData.get_data("https://www.amazon.in/")
#     URL ="https://www.amazon.in/"
#     print(URL)
#     driver.get(URL)
#    # Reports.AddStepDetailsToTestcaseHTML("Opening the site ","Site opened","Site opened", 'PASS', "amazonHomePage")
#     time.sleep(1)
# def siteLogin():
#     driver.find_element(By.XPATH, value='//*[@id="nav-link-accountList"]').click()
#     #username button
#     driver.find_element(By.ID,value='ap_email').send_keys('8870294361')
#     #continue button
#     driver.find_element(By.ID,value='continue').click()
#     #password button
#     driver.find_element(By.XPATH, value='//*[@id="ap_password"]').send_keys('golden bell')
#     #signin button
#     driver.find_element(By.ID, value='signInSubmit').click()
#     print("login sucess")
#     #Reports.AddStepDetailsToTestcaseHTML("Login with Valid username & Password ", "Login in Sucessfull", "Login in Sucessfull", 'PASS',"amazonHomePage with username")
# def openBrowser2():
#     #URL = GetData.get_data("https://www.fanuc.com/")
#     URL = "https://www.fanuc.com/"
#     print(URL)
#     driver.get(URL)
#     time.sleep(2)
#
# driverInit("chrome")
# openBrowser1()
# siteLogin()
# driverClose()
# driverInit("chrome")
# openBrowser2()
# driverClose()
