#from Framework_Components.GetData import *
import time
from selenium.webdriver import ActionChains

from AutomationLibraries.WebAutomation import driver
from Framework_Components import Reports
from Framework_Components.GetData import *
import time
from selenium.webdriver.common.by import By
from Framework_Components import GetData
# All browser web driver should be saved inside Framework Folder -> Resources -> AutomationDrivers Folder
# For Selenium Test cases "Web Driver" will be auto initialised & closed at start & end of each test case.

def openBrowser():
    URL = GetData.get_data("URL")
    print(URL)
    driver.get(URL)
    Reports.AddStepDetailsToTestcaseHTML("Opening the site ","Site opened","Site opened", 'PASS', "amazonHomePage")
    time.sleep(1)

def siteLogin():
    driver.find_element(By.XPATH, value='//*[@id="nav-link-accountList"]').click()
    #username button
    driver.find_element(By.ID,value='ap_email').send_keys('8870294361')
    #continue button
    driver.find_element(By.ID,value='continue').click()
    #password button
    driver.find_element(By.XPATH, value='//*[@id="ap_password"]').send_keys('golden bell')
    #signin button
    driver.find_element(By.ID, value='signInSubmit').click()
    Reports.AddStepDetailsToTestcaseHTML("Login with Valid username & Password ", "Login in Sucessfull", "Login in Sucessfull", 'PASS',"amazonHomePage with username")

def searchProduct():
    #actions = ActionChains(driver)
    time.sleep(1)
    driver.find_element(By.XPATH, value='//*[@id="twotabsearchtextbox"]').send_keys("Hp laptop")
    time.sleep(1)
    driver.find_element(By.XPATH,value='//*[@id="nav-search-submit-button"]').click()
    time.sleep(1)
    Reports.AddStepDetailsToTestcaseHTML("Searching for HP Laptop", "Navigated to HP latop page", "Navigated to HP latop page", 'PASS',"HP_Laptop_page")

def AddFilters():
    driver.find_element(By.ID, value='p_89/HP').click()
    driver.find_element(By.XPATH, value='//*[@id="p_n_feature_browse-bin/27969054031"]/span/a/div/label/i').click()
    driver.find_element(By.LINK_TEXT,value="(Renewed) HP ProBook Intel 6th Gen Core i5 14 inches FHD Screen Laptop (8GB RAM, 256GB SSD, HD Graphics, Windows 11 (Upgraded), MS Office, Black, Slim)").click()
    Reports.AddStepDetailsToTestcaseHTML("Applying Brand Filter ", "HP filter applied","HP filter applied", 'PASS', "HP_Laptop_pageWithFilters")

