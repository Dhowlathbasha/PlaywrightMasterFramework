import time

from Framework_Components.GetData import *
from Framework_Components import Reports, GetData
from Robot_Specific_Components import Eva
from Utils import Voice
from Utils.ocrUtils import *



def Login():
    username = GetData.get_data("UserName")
    password = GetData.get_data("Password")
    EvaStatus = Eva.run_Eva(username)
    if EvaStatus == 200:
        status = 'PASS'
    else:
        status = 'FAIL'
    Reports.AddStepDetailsToTestcaseHTML("Entering User name ", username, "User name Entered Sucessfully", "User name Entered Sucessfully",status ,"NA")
    EvaStatus = Eva.run_Eva(password)
    if EvaStatus == 200:
        status = 'PASS'
    else:
        status = 'FAIL'
    Reports.AddStepDetailsToTestcaseHTML("Entering password name ", password, "password Entered Sucessfully","Password Entered Sucessfully", status, "Homescreen")


def SelectItem():
    print("This is from select item")
    itemID = GetData.get_data("ItemID")
    itemID = str(itemID)
    Reports.AddStepDetailsToTestcaseHTML("Selecting Item for Purchase ", itemID, "Item added to purchase list","Item added to purchase list", "PASS", "PurchaseItemList")

def Transaction():
    pickCard = GetData.get_data("cardPick")
    InsertCard = GetData.get_data("Insert")
    cardInsert  = pickCard+"-"+InsertCard
    Reports.AddStepDetailsToTestcaseHTML("Inserting card1 in Terminal 1", cardInsert, "Card insertion Successful","Card insertion Successful", "PASS", "NA")
    pin = GetData.get_data("PIN")
    Reports.AddStepDetailsToTestcaseHTML("Entering pin ", pin, "Pin Entry Sucessful", "Pin Entry Sucessful", "PASS", "NA")
    RemoveCard = GetData.get_data("PlaceCard")
    Reports.AddStepDetailsToTestcaseHTML("Remove & Place card ", RemoveCard, "Successfully Card Removed and placed", "Successfully Card Removed and placed", "PASS","NA")
    CollectReceipt = GetData.get_data("Collect Receipt")
    Reports.AddStepDetailsToTestcaseHTML("Receipt Collection ", CollectReceipt, "Successfully collected the receipt from printer","Successfully collected the receipt from printer", "PASS", "NA")

def FullPayment():

    Reports.AddStepDetailsToTestcaseHTML("Making Payment ", "full payment ", "Transaction Sucessful","Transaction Sucessful", "PASS", "NA")


def pinEntery():

    Reports.AddStepDetailsToTestcaseHTML("Entering pin ", "pin - 1112", "pin Entered Sucessfully",
                                         "User name Entered Sucessfully", "PASS", "NA")


def CollectReceipt():

    json_body = GetData.get_data("getImage Post Body")
    textract = Image_Validation_Method("Azure", 1)
    Reports.AddStepDetailsToTestcaseHTML("Collect Recepit ","Text Extraction", textract,
                                         textract, "PASS", "Items purchased and bill amount present text extracted ")
    expected = "HDFC-DEBIT-CARD-GLOBAL-CONTACTLESS"
    validation,accuracy = textValidation(textract,expected)

    Reports.AddStepDetailsToTestcaseHTML("Collect Recepit ", "Text Extraction", textract,
                                         expected+f"<br> Accuracy : {accuracy} <br> Validation : {validation}", "PASS", "Items purchased and bill amount present text extracted ")
def Logout():

    close_app = GetData.get_data("Close_APP")
    Reports.AddStepDetailsToTestcaseHTML("Logout ", close_app,"Successfully closed the app","Successfully closed the app", "PASS", "closeApp")


def voiceValidation_german():
    print("Voice Validation")
    Voice.StartRecording()
    time.sleep(20)
    Voice.stopRecording()
    voiceOutput = Voice.get_large_audio_transcription('german')
    outputPercentage,missingList = Voice.voiceValidation(voiceOutput,"Willkommen. Bitte legen Sie Ihre Karte ein, um zu beginnen. Wenn Sie diese Maschine noch nie benutzt haben, legen Sie Ihre Karte bitte noch nicht ein, es werden noch Anweisungen abgespielt. Wenn Sie diese Anweisungen nicht wünschen, können Sie Ihre Karte jederzeit einführen, um die Maschine zu verwenden. Die Transaktion kann mit dem PIN-Pad abgeschlossen werden, das wie die Telefontastatur außerhalb eingerichtet ist")
    if (int(outputPercentage) > 80):
        status = "PASS"
    else:
        status = "FAIL"
    Reports.AddStepDetailsToTestcaseHTML("GermanTextValidation ", "",
                                         "Willkommen. Bitte legen Sie Ihre Karte ein, um zu beginnen. Wenn Sie diese Maschine noch nie benutzt haben, legen Sie Ihre Karte bitte noch nicht ein, es werden noch Anweisungen abgespielt. Wenn Sie diese Anweisungen nicht wünschen, können Sie Ihre Karte jederzeit einführen, um die Maschine zu verwenden. Die Transaktion kann mit dem PIN-Pad abgeschlossen werden, das wie die Telefontastatur außerhalb eingerichtet ist",
                                         "outputPercentage\n" + missingList, status, "NA")


def voiceValidation_eng():
    print("Voice Validation")
    Voice.StartRecording()
    time.sleep(20)
    Voice.stopRecording()
    voiceOutput = Voice.get_large_audio_transcription('german')
    outputPercentage,missingList = Voice.voiceValidation(voiceOutput,"Welcome. Please insert your card to start. if you have not used this machine before please don't insert your card just yet instructions will be played. if you dont want this instructions you can insert you card any time to start using the machine. Transaction can be completed with the pin pad which is setup outside the like the telephonic keypad")
    if(int(outputPercentage)>80):
        status = "PASS"
    else:
        status = "FAIL"
    Reports.AddStepDetailsToTestcaseHTML("EnglishTextValidation ", "", "Welcome. Please insert your card to start. if you have not used this machine before please don't insert your card just yet instructions will be played. if you dont want this instructions you can insert you card any time to start using the machine. Transaction can be completed with the pind pad which is setup outside the like the telephonic keypad",
                                         "outputPercentage\n"+missingList, status, "NA")

