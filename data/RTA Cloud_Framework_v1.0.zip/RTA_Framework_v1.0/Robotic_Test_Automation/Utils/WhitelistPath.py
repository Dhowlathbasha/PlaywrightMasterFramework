import os
import pathlib
import pathlib

def getCurrentDirectory():
    Path = pathlib.Path().absolute()
    print(Path)
    return Path

def getParentPath():
    Path = pathlib.Path().absolute()
    ParentPath = Path.parent.absolute()
    ParentPath = str(ParentPath)
    ParentPathstr= ParentPath.replace('\\','/')
    print(ParentPathstr)
    return ParentPathstr

def getCurrentFilePath():
    path = pathlib.Path(__file__)
    return path