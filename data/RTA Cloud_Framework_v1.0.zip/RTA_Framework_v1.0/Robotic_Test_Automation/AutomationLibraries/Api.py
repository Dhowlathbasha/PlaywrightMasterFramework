import time

import requests
from enum import Enum
from multipledispatch import dispatch
from Framework_Components import Reports

@dispatch(str,str,str,dict,int)
def getresponse(url=None,method=None,postbody=None,header=None,statusCode=None):

    if method == "POST":
        api_response = requests.post(url=url, data=postbody)

        if api_response.status_code != statusCode:
            print("the status code is : ", api_response.status_code)
        else:
            data = str(api_response.content)
            return data
    if method == "PUT":
        api_response = requests.put(url=url, data=postbody, headers=header)

        if api_response.status_code != statusCode:
            print("the status code is : ", api_response.status_code)
        else:
            data = str(api_response.content)
            return data

@dispatch(str,str,dict,int)
def getresponse(url=None,method=None,header=None,statusCode=None):
    if method == "GET":
        api_response = requests.get(url)
        return api_response
    if method == "DELETE":
        api_response = requests.delete(url, headers=header)
        return api_response


def JsonParser(json,key):
    config = json
    for i in key.split("."):
        if i in config:
            config = config[i]
        else:
            return None
    return config

def ResponseValidation(Stepname,url,response,AssertResponse,JSONKeyPath,ExpectedValue,ValidationType):
    if(AssertResponse.lower() == 'tag'):
        ValidationString = JsonParser(response,JSONKeyPath)
        if (ValidationType.lower() == 'equals'):
            if (str(ValidationString) == ExpectedValue):
                Reports.AddStepDetailsToTestcaseHTML(Stepname, url, ExpectedValue, str(ValidationString), "PASS", "NA")
            else:
                Reports.AddStepDetailsToTestcaseHTML(Stepname, url, ExpectedValue, str(ValidationString), "FAIL", "NA")

        if (ValidationType.lower() == 'contains'):
            if (str(ExpectedValue) in ValidationString):
                Reports.AddStepDetailsToTestcaseHTML(Stepname, url, ExpectedValue, str(ValidationString), "PASS", "NA")
            else:
                Reports.AddStepDetailsToTestcaseHTML(Stepname, url, ExpectedValue, str(ValidationString), "FAIL", "NA")
    if(AssertResponse.lower() == 'body'):
        if (response.lower() == 'equals'):
            if (str(response) == ExpectedValue):
                Reports.AddStepDetailsToTestcaseHTML(Stepname, url, ExpectedValue, str(response), "PASS",                                                     "NA")
            else:
                Reports.AddStepDetailsToTestcaseHTML(Stepname, url, ExpectedValue, str(response), "FAIL",                                                     "NA")
        if (ValidationType.lower() == 'contains'):
            if (str(ExpectedValue) in response):
                Reports.AddStepDetailsToTestcaseHTML(Stepname, url, ExpectedValue, str(response), "PASS","NA")
            else:
                Reports.AddStepDetailsToTestcaseHTML(Stepname, url, ExpectedValue, str(response), "FAIL","NA")


