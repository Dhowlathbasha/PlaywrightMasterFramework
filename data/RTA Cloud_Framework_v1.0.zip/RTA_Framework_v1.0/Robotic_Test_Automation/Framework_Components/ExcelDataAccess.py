import sys
import threading

import pandas as pd
import os
import importlib
import time
from os.path import abspath
from Framework_Components import Reports, GetData
import webbrowser
from Framework_Components.GetData import *
from AutomationLibraries import WebAutomation

#Heading = "RTA - TSB - Automation Execution Results Summary"
#RunConfiguration = "EVA - Local"
from Utils import video

global ReportFolderFullPath
global CurrenttestcaseHTMLPath
global test_scenario
global current_testcase
global testconfiguration
class ExcelDataAccess():

    current_testcase = ''
    test_scenario = ''

    def __int__(self):
        self.df = self.df
        self.index = self.index
        self.df_new = self.df_new
        self.testcase = self.testcase
        self.keyword_df = self.keyword_df
        self.test_scenario_df = self.test_scenario_df
        self.testcase_index = self.testcase_index
        self.SummaryHTMLFilePath = self.SummaryHTMLFilePath
        self.testconfiguration = self.testconfiguration


# Generate  Report Folder (Current Date Time Name - "%d/%m/%Y %H:%M:%S" ) with empty summary.html
    def generateSummaryHTML(self):
        summaryTemplateFilePath = abspath("ReportsTemplates/summaryTemplate.txt")
        ReportFolderPath = abspath("Report/")
        global ReportFolderFullPath
        ReportFolderFullPath = Reports.CreateReportFolder(ReportFolderPath)
        self.SummaryHTMLFilePath = os.path.abspath(ReportFolderFullPath + "/" + "summary.html")
        Heading = GetData.get_configuration("Report","Heading")                                          #Reading values from properties.ini
        RunConfiguration = GetData.get_configuration("Report","RunConfiguration")                        #Reading values from properties.ini
        Reports.createsummmaryHTML(Heading, RunConfiguration, summaryTemplateFilePath, self.SummaryHTMLFilePath)

# Get index of testcase which are marked as YES form RunnerMannger.csv
    def get_runmanager_testcase_index (self):
        try:
            runmannager_path = abspath("Resources/RunnerManager.csv")
            self.df = pd.read_csv(runmannager_path)
            self.df_new = self.df[self.df['Execute'] == 'Yes']
            if self.df_new.empty:
                raise Exception
            self.index = self.df_new.index.to_list()
            return self.index  # [0,2]
        except FileNotFoundError:
            print("Runner Manager File is not found in the Framework")
        except Exception:
            print("No Test Case has the Execution status as YES")
            sys.exit(0)

#Get the Name of the test case using index obtained from get_runmanager_testcase_index method
    def get_testcase(self):
        self.testcase = self.df_new['Testcase'].to_list()   #['TC1', 'TC3']
        return self.testcase

    def get_keywords(self):
        try:
            self.keyword_df = {}
            for testcase in self.testcase:  # Current Test case : i= 0 --> 'TC1', i=1 --> 'TC3'
                self.keyword_df[testcase] = []
            total_columns = len(self.df_new.columns)  # Total column in runmanger
            keyword_index = self.df_new.columns.get_loc("Keyword1")
            for index in self.index:
                keyword_list = []
                for i in range(keyword_index, total_columns):
                    column_name = self.df.columns[i]
                    if pd.isnull(self.df.loc[index, column_name]):
                        continue
                    else:
                        keyword = self.df.iloc[index, i]
                        keyword_list.append(keyword)
                # index =0 --> [Login,SelectItem,FullPayment,pinEntery,CollectReceipt,Logout] ; index=2 --> [Login,ReturnItem,collectCash,Logout]
                self.keyword_df[self.df.loc[index, 'Testcase']]+=(keyword_list)
                if len(keyword_list) == 0:
                    raise Exception
                #  {'TC1': [Login,SelectItem,FullPayment,pinEntery,CollectReceipt,Logout] , 'TC2' :[Login,ReturnItem,collectCash,Logout] }
            return self.keyword_df
        except Exception:
            print("No Keywords found for the current Test case")
            sys.exit(0)


    def search_keyword(self,keyword):
        package_path = abspath('Business_Components')
        directory = os.listdir(package_path)
        for fname in directory:
            if os.path.isfile(package_path + os.sep + fname):
                f = open(package_path + os.sep +fname, 'r')
            if keyword in f.read():
                return fname[:fname.find((".py"))]
            else:
                continue
            f.close()

    def keyword_execution(self):

        for key, values in self.keyword_df.items():
            ExcelDataAccess.current_testcase = key
           # print("key"+key)
            global current_testcase
            global ReportFolderFullPath
            global CurrenttestcaseHTMLPath
            global test_scenario
            #global testConfiguration
            current_testcase = key
            testconfig = ExcelDataAccess.get_test_configuration(self)

            #Checking video Recording is enabled and start recording video
            videoRecording = GetData.get_configuration("VideoRecording", "Recording")

            # if videoRecording.lower() == 'enable':
            #     t1 = threading.Thread(target=video.capturevideo, name='VoiceRecording')
            #     t1.start()
            #     while(video.videostarted != 'started'):
            #         continue

            #time.sleep(1)
            if 'WEB' in testconfig:

                browser = testconfig.split('-')
                browserID = browser[1]
                WebAutomation.driveraction(browserID)

            ######################################  Test html file for current test case #############

            TestcaseTemplateFilePath = abspath("ReportsTemplates/TestcaseHeading.txt")

            CurrenttestcaseHTMLPath = ReportFolderFullPath + "/" + ExcelDataAccess.current_testcase + ".html"
            RunConfiguration = GetData.get_configuration("Report","RunConfiguration")  # Reading values from properties.ini
            Reports.createTestcaseHTMLTemplate(ExcelDataAccess.current_testcase, RunConfiguration, TestcaseTemplateFilePath)
            Reports.testcase_passcount = 0
            Reports.testcase_failcount = 0
            #print(ExcelDataAccess.get_test_scenario(self))

            test_scenario = ExcelDataAccess.get_test_scenario(self)

            #print(ExcelDataAccess.get_test_description(self))
            for value in values:
                fname = ExcelDataAccess.search_keyword(self,value)
                function_path = "Business_Components."+fname
                mod = importlib.import_module(function_path)
                ######## Adding Method to current testcase.html
                Reports.AddMethodNameToTestcaseHTML(value, CurrenttestcaseHTMLPath)
                func = getattr(mod, value)
                func()

            if 'WEB' in testconfig:
                WebAutomation.driveraction("close")
            video.recording = False # to stop video recording
            if Reports.testcase_failcount > 0 :
                Reports.Summary_failCount = Reports.Summary_failCount +1
            else:
                Reports.Summary_Passcount = Reports.Summary_Passcount+1

            Reports.createTestcaseHTMLFooter(CurrenttestcaseHTMLPath,self.SummaryHTMLFilePath, ExcelDataAccess.get_test_scenario(self), ExcelDataAccess.current_testcase, ExcelDataAccess.get_test_description(self))

    def get_test_scenario(self):
        self.test_scenario_df = self.df_new[self.df_new['Testcase'] == ExcelDataAccess.current_testcase]
        testcase_index = self.test_scenario_df.index.to_list()
        self.testcase_index = testcase_index[0]
        test_scenario = self.test_scenario_df.loc[self.testcase_index, 'Test Scenario']
        return self.test_scenario_df.loc[self.testcase_index, 'Test Scenario']

    def get_test_configuration(self):
        global testconfiguration
        self.test_scenario_df = self.df_new[self.df_new['Testcase'] == ExcelDataAccess.current_testcase]
        testcase_index = self.test_scenario_df.index.to_list()
        self.testcase_index = testcase_index[0]
        testconfiguration = self.test_scenario_df.loc[self.testcase_index, 'TestConfiguration']
        #print(testconfiguration)
        return testconfiguration


    def get_test_description(self):
        return self.test_scenario_df.loc[self.testcase_index, 'Test Description']


    def generateHTMLFooter(self):
        Reports.createSummaryFooter(self.SummaryHTMLFilePath, Reports.Summary_Passcount, Reports.Summary_failCount)
        filename = 'file:///' + self.SummaryHTMLFilePath
        time.sleep(3)
        webbrowser.open_new_tab(filename)