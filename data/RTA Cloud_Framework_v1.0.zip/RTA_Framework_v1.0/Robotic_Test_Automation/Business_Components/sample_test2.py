from Framework_Components import GetData, Reports
from Framework_Components.GetData import *


def ReturnItem():

    TransactionID = GetData.get_data("TransactionID")
    #item_id = str(item_id)
    Reports.AddStepDetailsToTestcaseHTML("Returning product ", TransactionID, "Successfully return the product using transaction ID","Successfully return the product using transaction ID", "PASS", "NA")
    #print(item_id)


def collectCash():

    f8 = GetData.get_data("F8")
    Reports.AddStepDetailsToTestcaseHTML("Collect Cash ", f8, "Pressing F8", "Pressing F8", "PASS", "NA")
    