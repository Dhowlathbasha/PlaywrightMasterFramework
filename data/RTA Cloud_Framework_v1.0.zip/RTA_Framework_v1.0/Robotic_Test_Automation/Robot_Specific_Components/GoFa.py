import socket
import time

from Framework_Components import GetData
from Framework_Components.GetData import *


def run_GoFa(data):
    try:
        Address = GetData.get_configuration("GoFa", "GoFa_IP")
        port = GetData.get_configuration("GoFa", "GoFa_Port")
        s = socket.socket()
        #s.connect((Address, port))
        time.sleep(2)
        #Task1
         # data from dataprovider
        s.send(data.encode())               # encoding the data and sending the data to GoFa tcpip server
        receive = ''
        receive = s.recv(1024)  # receive the data from GoFa
        return receive
    except Exception as e:
        print("Exception occurred"+str(e))
        return str(e)



