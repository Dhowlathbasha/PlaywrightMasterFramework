from Framework_Components.ReusableLibrary import *


if __name__ == '__main__':
    obj = ResuableLibrary()
    obj.batch_executor()