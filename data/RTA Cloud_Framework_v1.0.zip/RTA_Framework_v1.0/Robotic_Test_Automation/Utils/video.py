import time
from os.path import abspath
from Framework_Components import ExcelDataAccess
from Framework_Components import GetData
import cv2
global recording
global videostarted
videostarted = ''
def capturevideo():
    global videostarted
    port = GetData.get_configuration("VideoRecording", "port")

    testcase_name = ExcelDataAccess.current_testcase
    vid = cv2.VideoCapture(int(port))
    width = int(vid.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(vid.get(cv2.CAP_PROP_FRAME_HEIGHT))
    path = ExcelDataAccess.ReportFolderFullPath + "/videos/" + testcase_name + ".mp4"
    writer = cv2.VideoWriter(abspath(path),
        cv2.VideoWriter_fourcc('m', 'p', '4', 'v'), 20, (width, height))
    global recording
    recording = True
    while (recording== True):
        global videostarted
        ret, frame = vid.read()
        writer.write(frame)
        cv2.imshow('frame', frame)
        videostarted = 'started'

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
    vid.release()
    writer.release()
    cv2.destroyAllWindows()
    videostarted =''