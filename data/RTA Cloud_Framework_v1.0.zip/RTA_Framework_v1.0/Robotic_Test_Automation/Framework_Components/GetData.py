import pandas as pd
from os.path import abspath
from Framework_Components import ExcelDataAccess
import configparser

#class GetData():
def get_data(fieldname):
    testScenario = ExcelDataAccess.test_scenario
    #print(testScenario)
    testdata_path = abspath('Resources/TestData.csv')
    testcase_df = pd.read_csv(testdata_path)
    current_testcase = ExcelDataAccess.current_testcase
    testcase_df_new = testcase_df[testcase_df['TC_ID'] == current_testcase]
    testcase_index = testcase_df_new.index.to_list()
    index = testcase_index[0]
    return testcase_df_new.loc[index, fieldname]


def get_configuration(section, key):
    config = configparser.ConfigParser()
    config.read(abspath('Resources/properties.ini'))
    string_val = config.get(section, key)
    return string_val


    # def set_configuration(section, key, value):
    #     config = configparser.ConfigParser()
    #     file = r'C:\Users\721479\Documents\Framework\EVA_Automation_1.3_JIRA\EVA_Automation_JIRA\EVA_Automation\Resources\properties.ini'
    #     config.read(file)
    #     config.set(section, key, value)
    #     with open(file, 'w') as configfile:  # save
    #         config.write(configfile)