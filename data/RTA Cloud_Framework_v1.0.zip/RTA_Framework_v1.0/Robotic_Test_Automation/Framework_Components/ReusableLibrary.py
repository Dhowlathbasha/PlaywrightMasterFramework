from Framework_Components.ExcelDataAccess import *


class ResuableLibrary():

    def __int__(self):
        pass

    def batch_executor(self):
        obj = ExcelDataAccess()
        obj.generateSummaryHTML()
        obj.get_runmanager_testcase_index()
        obj.get_testcase()
        obj.get_keywords()
        obj.keyword_execution()
        obj.generateHTMLFooter()



