from Framework_Components import Reports
from Framework_Components.GetData import *
from Robot_Specific_Components.Eva import run_Eva
from Robot_Specific_Components.GoFa import run_GoFa
from Utils.ocrUtils import Image_Validation_Method, textValidation


Maps = "open Map"

Music = "New_Infotainment_Music"
SearchBox = "MapSearch"
Click_direction = "Get_Direction"
startLocation = "startLocation"
Call = "New_Infotainment_Call"
mobileApp = "OpenMobileApp"
dialicon = "RecentDial"
callbutton = "CallButton"
CloseMap = " ClosingMap"
musicApp = "OpenMusicApp"
playSong = "PlayFirstSong"
CloseMusic = "CloseMusic"
# def Infotainment_Map():
#     # Home = "New_Infotainment_Home"
#     # Maps = "New_Infotainment_Maps"
#     # Back_BTN = "New_Infotainment_Back_BTN"
#     # Music = "New_Infotainment_Music"
#
#     Home_toolpath = run_Eva(Home)
#     if Home in Home_toolpath:
#         Reports.AddStepDetailsToTestcaseHTML(f"Running Toolpath {Home} ", Home, Home_toolpath + " ran Sucessfully",
#                                          Home_toolpath + " ran Sucessfully", "PASS", "NA")
#     else:
#         Reports.AddStepDetailsToTestcaseHTML("Running Toolpath ", Home, Home + " ran Sucessfully",
#                                              Home + " ran Sucessfully", "FAIL", "NA")
#     Map_toolpath = run_Eva(Maps)
#     if Maps in Map_toolpath:
#         Reports.AddStepDetailsToTestcaseHTML(f"Running {Maps} ", Maps, Map_toolpath + " ran Sucessfully",
#                                          Maps + " ran Sucessfully", "PASS", "NA")
#     else:
#         Reports.AddStepDetailsToTestcaseHTML(f"Running {Map_toolpath} ", Map_toolpath, Map_toolpath + " ran Sucessfully",
#                                              Maps + " ran Sucessfully", "FAIL", "NA")
#     run_Eva(Back_BTN)
#
# def Infotainment_call():
#     Call = "New_Infotainment_Call"
#     Call_toolpath = run_Eva(Call)
#     if Call in Call_toolpath:
#         Reports.AddStepDetailsToTestcaseHTML(f"Running {Call} ", Call, Call_toolpath + " ran Sucessfully",
#                                          Call + " ran Sucessfully", "PASS", "NA")
#     else:
#         Reports.AddStepDetailsToTestcaseHTML(f"Running {Call} ", Call, Call_toolpath + " ran Sucessfully",
#                                              Call + " ran Sucessfully", "FAIL", "NA")
#     #
#     # Music_toolpath = run_Eva(Music)
#     # if Music in Music_toolpath:
#     #     Reports.AddStepDetailsToTestcaseHTML("Running Toolpath ", Music, Music + " ran Sucessfully",
#     #                                          Music + " ran Sucessfully", "PASS", "NA")
#
# def Check_Destination():
#
#     textract = Image_Validation_Method("Azure", 0)
#     #expected = "CR SCAN 01 Quick Guide"
#     expected = "Every day is a new Beginning"
#     validation,accuracy = textValidation(textract,expected)
#
#     Reports.AddStepDetailsToTestcaseHTML("Check Destination ", "Text Extraction", expected,
#                                          textract+f"<br> Accuracy : {accuracy} <br> Validation : {validation}", validation, "Destination")
#
#
# def GoFa_Test():
#     run_GoFa("Philips")
