import threading
import os
import time
import speech_recognition as sr
import pyaudio
import queue
import sys
import time
import wave
import pyaudio
import speech_recognition as sr
from pydub import AudioSegment
from pydub.silence import split_on_silence
import sounddevice as sd
import soundfile as sf
import numpy  # Make sure NumPy is loaded before it is used in the callback
assert numpy  # avoid "imported but unused" message (W0611)
from google.cloud import speech
import shutil
from os.path import abspath
from Framework_Components import ExcelDataAccess


def VoiceRecording():

    q = queue.Queue()

    def callback(indata, frames, time, status):
        """This is called (from a separate thread) for each audio block."""
        if status:
            print(status, file=sys.stderr)
        q.put(indata.copy())

    try:

        global voiceRecord
        voiceRecord = True
        list_devices = False
        sampleRate = None
        device = None
        channels = 1
        subtype = None

        filename = os.path.abspath('Resources/WavFile/voiceoutput.wav')
        if sampleRate is None:
            device_info = sd.query_devices(device, 'input')
            # soundfile expects an int, sounddevice provides a float:
            sampleRate = int(device_info['default_samplerate'])

        # Make sure the file is opened before recording anything:
        with sf.SoundFile(filename, mode='x', samplerate=sampleRate,
                          channels=channels, subtype=subtype) as file:
            with sd.InputStream(samplerate=sampleRate, device=device,
                                channels=channels, callback=callback):
                print('#' * 80)
                print('Voice Recording Started')
                print('#' * 80)
                while voiceRecord == True:
                    file.write(q.get())
                # if voiceRecord == False:
                #     print('\nRecording finished: ' + repr(filename))

    except Exception as e:
        print(str(e))


def get_large_audio_transcription(lang):
        language_list = {"english": "en-US", "french": "fr-FR", "german": "de-DE", "japan": "ja-JP"}
        lang = language_list.get(lang)
        r = sr.Recognizer()
        """
        Splitting the large audio file into chunks
        and apply speech recognition on each of these chunks
        """
        # open the audio file using pydub

        filepath = os.path.abspath('Resources/WavFile/voiceoutput.wav')
        sound = AudioSegment.from_wav(filepath)
        # split audio sound where silence is 700 miliseconds or more and get chunks
        chunks = split_on_silence(sound,
                                  # experiment with this value for your target audio file
                                  min_silence_len=500,
                                  # adjust this per requirement
                                  silence_thresh=sound.dBFS - 14,
                                  # keep the silence for 1 second, adjustable as well
                                  keep_silence=500,
                                  )
        folder_name = os.path.abspath('Resources/WavFile/audio-chunks')
        if not os.path.isdir(folder_name):
            os.mkdir(folder_name)
        whole_text = ""
        # process each chunk
        for i, audio_chunk in enumerate(chunks, start=1):
            # export audio chunk and save it in
            # the `folder_name` directory.
            chunk_filename = os.path.join(folder_name, f"chunk{i}.wav")
            audio_chunk.export(chunk_filename, format="wav")
            with sr.AudioFile(chunk_filename) as source:
                audio_listened = r.record(source,language = lang)
                # try converting it to text
                try:
                    text = r.recognize_google(audio_listened)
                except sr.UnknownValueError as e:
                    print("Error:", str(e))
                else:
                    text = f"{text.capitalize()}. "
                    whole_text += text
        shutil.copyfile(os.path.abspath('Resources/WavFile/voiceoutput.wav'), ExcelDataAccess.ReportFolderFullPath+"/WavFile/"+ExcelDataAccess.current_testcase+".wav")
        os.remove(os.path.abspath('Resources/WavFile/voiceoutput.wav'))

        shutil.rmtree(os.path.abspath('Resources/WavFile/audio-chunks'))
        return whole_text

def StartRecording():
    t1 = threading.Thread(target=VoiceRecording, name='VoiceRecording')
    t1.start()
    time.sleep(2)


def stopRecording():
    global voiceRecord
    voiceRecord = False
    print('Voice Recording Stopped...')
    time.sleep(3)



def voiceValidation(actualText,ExpectedText):
    textpresent = 0
    MissingList = []
    if ' ' in ExpectedText:
        ExpectedText = ExpectedText.split(' ')

    else:
        ExpectedText = [ExpectedText]

    for i in range(len(ExpectedText)):
        if str(ExpectedText[i]).lower() in str(actualText).lower():
            textpresent = textpresent+1;
        else:
            print(str(ExpectedText[i])," is not in the actual text")
            MissingList.append(str(i))

    outputpercentage = (textpresent/len(ExpectedText)) * 100
    print(outputpercentage)

    return outputpercentage,MissingList
