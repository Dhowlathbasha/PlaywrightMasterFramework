import os
import pathlib

#from azure.ai.formrecognizer import DocumentAnalysisClient
#from azure.core.credentials import AzureKeyCredential
import io

from Framework_Components import GetData
from Framework_Components.GetData import *
# from google.cloud import vision
# from google.cloud import vision_v1
# from google.cloud.vision_v1 import types
# import boto3


class ocr_CloudComponents():

    textraction_client = None
    reko_client = None
    s3_client = None
    googleClient = None


   # def __init__(self):

        # AWS Cloud Components Initialization forg OCR
        # global textraction_client,reko_client,s3_client,googleClient
        # awsaccesskeyid= GetData.get_configuration("AWS","Access_Key_ID")
        # awssecret_accesskey = GetData.get_configuration("AWS","Secret_Access_Key")
        #
        # reko_client = boto3.client('rekognition', aws_access_key_id=awsaccesskeyid,
        #                       aws_secret_access_key=awssecret_accesskey, region_name='ap-south-1')
        # s3_client = boto3.client('s3', aws_access_key_id=awsaccesskeyid,
        #                            aws_secret_access_key=awssecret_accesskey, region_name='ap-south-1')
        # textraction_client = boto3.client('textract', aws_access_key_id=awsaccesskeyid,
        #                            aws_secret_access_key=awssecret_accesskey, region_name='us-east-1')
        #
        # # Google Cloud Components Initialization for OCR
        # Path = str(pathlib.Path().absolute())
        # os.environ['GOOGLE_APPLICATION_CREDENTIALS'] = Path+r'/Resources/vision_api.json'
        # googleClient = vision.ImageAnnotatorClient()


    #AWS Cloud Components for OCR

    def text_extraction(self, Location_selection, image):
        global textraction_client
        ResponseData = {"text": []}
        if Location_selection == '0':
            print("Textraction from Local")
            with open(image, 'rb') as document:
                Image_bytes = bytearray(document.read())

            response = textraction_client.detect_document_text(Document={'Bytes': Image_bytes})
            print(str(response))
            for item in response['Blocks']:
                if item['BlockType'] == 'LINE':
                    print(item['Text'])
                    ResponseData["text"].append(item['Text'])
            value = ResponseData.get("text")
            finalString = ""
            print(finalString.join(value))
            return finalString.join(value)
        else:
            print("Textraction from S3 Bucket")
            response = textraction_client.detect_document_text(
                Document={'S3Object': {
                    'Bucket': 'saravanantest',
                    'Name': 'Image.jpg',
                },
                })
            return response




        #Google OCR code

    # USe this method for detecting text in locally stored images
   # def detect_text(self,img):
        # with io.open(img, 'rb') as image_file:
        #     content = image_file.read()
        #
        # image = vision_v1.types.Image(content=content)
        # response = googleClient.document_text_detection(image=image, image_context={"language_hints": ["eng"]})
        #
        # texts = response.full_text_annotation.text
        # return texts

    # To extract text from Image Url's
   # def detect_text_url(self,image_url):
        # image = vision_v1.types.Image()
        # image.source.image_uri = image_url
        #
        # response = googleClient.document_text_detection(image=image, image_context={"language_hints": ["ja"]})
        # texts = response.full_text_annotation
        # return texts


    #Azure Cloud Components for OCR

   # def analyze_read(self,imagePath):
        # sample form document
        #
        # endpoint = GetData.get_configuration("Azure","Endpoint")
        # key = GetData.get_configuration("Azure","Access_Key")
        # image = imagePath
        # formUrl = open(image, "rb")
        #
        # # create your `DocumentAnalysisClient` instance and `AzureKeyCredential` variable
        # document_analysis_client = DocumentAnalysisClient(
        #     endpoint=endpoint, credential=AzureKeyCredential(key)
        # )
        #
        # poller = document_analysis_client.begin_analyze_document(
        #     "prebuilt-read", formUrl)
        # result = poller.result()
        # print(result.content)
        # return result.content
