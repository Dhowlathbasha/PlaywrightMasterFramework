import datetime
import os
import shutil
from os.path import abspath

from multipledispatch import dispatch

from AutomationLibraries import WebAutomation
from Framework_Components import ExcelDataAccess
import time
#TestcaseName = "EVA - POS Automation"
global Summary_CurrentTest_Status
Summary_CurrentTest_Status = "PASSED"
global testcase_passcount
testcase_passcount = 0
global testcase_failcount
testcase_failcount = 0
#global Summary_Passcount
Summary_Passcount = 0
#global Summary_failCount
Summary_failCount = 0
Image_path = abspath("Resources\Images\image.jpg")
#r'C:\Users\721462\Downloads\RTA_Framework0.2\Robotic_Test_Automation\Resources\Images\image.jpg'

#################################### REUSABLE METHODS ##############################################


def currentTime():
    CurrentTime = datetime.datetime.now().strftime('%Y-%b-%d %H:%M:%S')
    return CurrentTime

def fileread(FilePath):
    with open(FilePath, mode='r') as file:
        FileContent = file.read()
        file.close()
        return FileContent
def fileWrite(FilePath,dateTowrite):
    with open(FilePath, mode='w',encoding="utf-8") as file:
        file.write(dateTowrite)
        file.close()

def fileAppend(FilePath,dataToAppend):
    with open(FilePath, mode='a', encoding="utf-8") as file:
        file.write(str(dataToAppend))
        file.close()
def copyFile(Source_FilePath, Destination_FileName):
    source_Path=os.path.abspath(Source_FilePath)
    Destination_Path = os.path.abspath(Destination_FileName)
    shutil.copyfile(source_Path, Destination_Path)
    #os.remove(source_Path)


##################### SUMMARY HTML #############################



def SummaryHTMLHeader(Heading,ResultDate,RunConfiguration):
    heading = "<body> <table id='header'> \n <thead> \n <tr class='heading'> \n <th colspan='4' style='font-family:Copperplate Gothic; font-size:1.4em;'>" \
              ""+Heading+"</th> \n </tr> \n <tr class='subheading'>\n <th>&nbsp;Date&nbsp;&&nbsp;Time</th>\n <th>&nbsp;:" \
            ""+ResultDate+"</th> \n <th>&nbsp;Run&nbsp;Configuration</th> \n <th>&nbsp;:"+RunConfiguration+"</th>\n</tr>\n </thead> </table>" \
            ""+"<table id='main'> \n <colgroup> \n<thead>  \n<tr class='heading'> \n <th>Test Scenario</th> \n <th>Test Case</th> \n <th>Test case Report Link</th> \n <th>Test Description</th> \n <th>Test Status</th> \n</tr>\n </thead>"
    return heading

def Summary_TestCase_Details(scenarioName,TestCase,TestcaseReportLink,TestDescription,TestStatus):
    Class = ""
    if TestStatus.lower() == "failed":
        Class = "fail"
    if TestStatus.lower() == "passed":
        Class = "pass"
    testcaseStatus = "<tr class='content' > \n\t <td class='justified'>"+scenarioName+"</td>" \
                      " \n\t <td class='justified'>"+TestCase+"</td>" \
                       "\n\t<td class='justified'>"+'<a href = '+'"'+TestcaseReportLink+'"\t  '+'target="about_blank">TestcaseReportLink'+"</a></td>" \
                        "\n\t<td class='justified'>"+TestDescription+"</td>" \
                            "<td class='"+Class+"'><b>"+TestStatus+"</b></td></tr>"
    return testcaseStatus

def SummaryFooterProperties():
    footerProperties = " </tbody> \n\t </table> \n\n \t\t <table id='footer'> \n\t\t\t <colgroup> " \
                       "\n\t\t\t\t <col style='width: 25%' /> " \
                       "\n\t\t\t\t <col style='width: 25%' />" \
                       "\n\t\t\t\t <col style='width: 25%' /> " \
                       "\n\t\t\t\t <col style='width: 25%' /> " \
                       "\n\t\t\t\t </colgroup> "
    return footerProperties

def FooterContent(passcount,failcount):
    passcount = str(passcount)
    failcount = str(failcount)
    tableContent = "<tfoot> \n\t <tr class='heading'> \n\t\t <th colspan='4'> Total Duration: " + "Summary "+ " " \
                    "</th>\n\t\t\t</tr> \n\t\t\t <tr class='content'>  \n\t\t\t <td class='pass'>&nbsp;Tests passed</td>" \
                    " \n\t\t\t  <td class='pass'>&nbsp;:"+passcount+"</td> \n\t\t\t <td class='fail'>&nbsp;Tests failed</td> " \
                    "\n\t\t\t <td class='fail'>&nbsp;:"+failcount+"</td> \n\t\t\t\t </tr>\n\t\t\t\t " \
                    "</tfoot>\n\t\t\t\t </table>\n\t\t\t\t </body> \n\t\t\t\t</html>"
    return tableContent

def createSummaryFooter(SummaryHTMLFilePath,passcount,failcount):
    footerProperties = SummaryFooterProperties()
    fileAppend(SummaryHTMLFilePath, footerProperties)
    FooterTableContent = FooterContent(passcount,failcount)
    fileAppend(SummaryHTMLFilePath, FooterTableContent)

##################### TESTCASE HTML #############################

def TestcaseHTMLHeading(TestcaseName,CurrentTime,ExecutionMode):
    heading = ''
    if 'web' in ExcelDataAccess.testconfiguration.lower():
        heading = "<body> \n <table id='header'> \n <thead> \n <tr class='heading'> \n <th colspan='4' style='font-family:Copperplate Gothic; font-size:1.4em;'> " \
                  "" + TestcaseName + "   -  Automation Execution Results \n </th> \n </tr> \n <tr class='subheading'> \n <th>&nbsp;Date&nbsp;&&nbsp;Time</th><th>" \
                                      "" + CurrentTime + "</th> <th>&nbsp;ExectuionMode&nbsp;</th> \n <th>" + ExecutionMode + "</th>\n</tr> \n </thead> </table>  " + "<table id='main'>\n <thead> \n <tr class='heading'> \n <th>Step Name</th>\n <th>Expected Response</th> \n <th>Actual Response</th> \n <th>Status</th> \n <th>SNAP SHOT</th> \n </tr> \n </thead> "

        pass
    else:
        heading = "<body> \n <table id='header'> \n <thead> \n <tr class='heading'> \n <th colspan='4' style='font-family:Copperplate Gothic; font-size:1.4em;'> " \
                  "" + TestcaseName + "   -  Automation Execution Results \n </th> \n </tr> \n <tr class='subheading'> \n <th>&nbsp;Date&nbsp;&&nbsp;Time</th><th>" \
                                      "" + CurrentTime + "</th> <th>&nbsp;ExectuionMode&nbsp;</th> \n <th>" + ExecutionMode + "</th>\n</tr> \n </thead> </table>  " + "<table id='main'>\n <thead> \n <tr class='heading'> \n <th>Step Name</th> \n <th>ToolPath</th> \n <th>Expected Response</th> \n <th>Actual Response</th> \n <th>Status</th> \n <th>SNAP SHOT</th> \n </tr> \n </thead> "
    return heading

def addTestMethodTemplate(methodName):
    TestStep = "<tbody id='Iteration1' style='display:table-row-group'> \n" \
               "<tr class='subsection'> \n" \
               "<td colspan='6' onclick=""toggleSubMenu('Iteration1ValidateUser')"">&nbsp;"+methodName+"</td> </tr> "
    return TestStep

def addstepDetailsTemplate(stepname,request,response,expected,status,snapshot):
    if status.lower() == 'pass':
        statusClass = 'pass'
    if status.lower() == 'fail':
        statusClass = 'fail'
    if snapshot.lower() == 'na':
        stepdetails = "\n\n<tr class='content' id='" + stepname + "'>\n" \
         " <td class='justified'>" + stepname + "</td>\n " \
           "<td class='justified'>" + request + "</td> \n" \
            "<td class='justified'>" + expected + "</td>\n" \
              " <td class='justified'>" + response + "</td>\n " \
                "<td class='" + statusClass + "'><b>" + status + "</b></td>\n" \
                  " <td class='justified'>" + snapshot + "</td>\n "

    else:
        current_Result_Image_Folder = ExcelDataAccess.ReportFolderFullPath+"/images/"+snapshot+".jpg"
        copyFile(Image_path,current_Result_Image_Folder)

        stepdetails = "\n\n<tr class='content' id='" + stepname + "'>\n" \
                       " <td class='justified'>" + stepname + "</td>\n " \
                        "<td class='justified'>" + request + "</td> \n" \
                          "<td class='justified'>" + expected + "</td>\n" \
                            " <td class='justified'>" + response + "</td>\n " \
                              "<td class='" + statusClass + "'><b>" + status + "</b></td>\n" \
                               " <td class='justified'>" + '<a href = ' + '"' + current_Result_Image_Folder + '" \t ' \
                                  ' ' + 'target= "about_blank">'+snapshot+'</a>' + "</td>\n</tr>\n"
    return stepdetails

def addstepDetailsInwebTemplate(stepname,response,expected,status,snapshot):
    if status.lower() == 'pass':
        statusClass = 'pass'
    if status.lower() == 'fail':
        statusClass = 'fail'
    if snapshot.lower() == 'na':
        stepdetails = "\n\n<tr class='content' id='" + stepname + "'>\n" \
         " <td class='justified'>" + stepname + "</td>\n " \
            "<td class='justified'>" + expected + "</td>\n" \
              " <td class='justified'>" + response + "</td>\n " \
                "<td class='" + statusClass + "'><b>" + status + "</b></td>\n" \
                  " <td class='justified'>" + snapshot + "</td>\n "

    else:

        current_Result_Image_Folder = ExcelDataAccess.ReportFolderFullPath+"/images/"+snapshot+".png"
        WebAutomation.takescreen(current_Result_Image_Folder)
        #copyFile(Image_path,current_Result_Image_Folder)

        stepdetails = "\n\n<tr class='content' id='" + stepname + "'>\n" \
                       " <td class='justified'>" + stepname + "</td>\n " \
                          "<td class='justified'>" + expected + "</td>\n" \
                            " <td class='justified'>" + response + "</td>\n " \
                              "<td class='" + statusClass + "'><b>" + status + "</b></td>\n" \
                               " <td class='justified'>" + '<a href = ' + '"' + current_Result_Image_Folder + '" \t ' \
                                  ' ' + 'target= "about_blank">'+snapshot+'</a>' + "</td>\n</tr>\n"
    return stepdetails

##################### FOOTER #############################

def testcaseHTMLFooterProperties():
    properties = " <table id='footer'> \n <colgroup> \n <col style='width: 25%' /> " \
                 " \n <col style='width: 25%' /> \n" \
                 " <col style='width: 25%' /> \n" \
                 "<col style='width: 25%' /> \n" \
                 " </colgroup> "
    return properties
def testcase_FooterTemplate(passcount,failcount):
    passcount = str(passcount)
    failcount = str(failcount)
    exectionDuration = " \n\t<foot>\n <tr class='heading'> \n <th colspan='4'>Execution Duration:\t\t"+"Summary"+"</th></tr>\n\n " \
                       "<tr class='subheading'> \n <td class='pass'>&nbsp;Steps passed</td> \n " \
                       "<td class='pass'>&nbsp;:"+ passcount+"</td> \n <td class='fail'>&nbsp;Steps failed</td> \n " \
                       "<td class='fail'>&nbsp;:"+failcount +"</td> \n </tr> \n\n </tfoot> \n\n\t </table> \n\n\t\t </body>\n\n</html> "
    return exectionDuration


############################################### Report Generation Starting #######################################3

def CreateReportFolder(ReportFolderPath):
    FolderName = str(currentTime())
    FolderName = FolderName.replace(":","-")
    FolderName = FolderName.replace(" ", "_")
    ReportFolderFullPath = os.path.abspath(ReportFolderPath+"/"+FolderName)
    if not os.path.isdir(ReportFolderFullPath):
        os.mkdir(ReportFolderFullPath)
        os.mkdir(ReportFolderFullPath+"/images")
        os.mkdir(ReportFolderFullPath + "/videos")

        return ReportFolderFullPath

def createsummmaryHTML(Heading,RunConfiguration,summaryTemplateFilePath,SummaryHTMLFilePath):
    CurrentTime  = currentTime()
    finalSummaryHeading = SummaryHTMLHeader(Heading,CurrentTime,RunConfiguration)
    summaryaHTMLproperties = fileread(summaryTemplateFilePath)   # Read summary Template File (.txt)
    fileWrite(SummaryHTMLFilePath,summaryaHTMLproperties)       #  convert&create Template File.txt  to summary.html in reports folder
    fileAppend(SummaryHTMLFilePath,finalSummaryHeading)         # Append Summary Header to summary.html

def createTestcaseHTMLTemplate(TestcaseName,ExectionMode,TestHeadingTemplateFilePath):
    #testcaseHTMLPath = Reports.CurrenttestcaseHTMLPath
    testcaseHTMLPath = ExcelDataAccess.CurrenttestcaseHTMLPath
    global Summary_CurrentTest_Status
    Summary_CurrentTest_Status = "PASSED"
    TestcaseStartTime = currentTime()
    #ExectionMode = "Local"

    TestCaseHTMLTemplateHeadingTable = TestcaseHTMLHeading(TestcaseName,TestcaseStartTime,ExectionMode)
    testcaseHTMLproperties = fileread(TestHeadingTemplateFilePath)
    fileWrite(testcaseHTMLPath, testcaseHTMLproperties)
    fileAppend(testcaseHTMLPath,TestCaseHTMLTemplateHeadingTable)

def AddMethodNameToTestcaseHTML(methodName,testcaseHTMLPath):
   # loginMethod = "POSLogin"
    addtestStep = addTestMethodTemplate(methodName)
    fileAppend(testcaseHTMLPath, addtestStep)

# robot related reports contains 6 headings
@dispatch(str,str,str,str,str,str)
def AddStepDetailsToTestcaseHTML(stepname,request,response,expected,status,snapshot):
    testcaseHTMLPath = ExcelDataAccess.CurrenttestcaseHTMLPath

  #  snapshot = "C:/Users/721479/Documents/Framework/RTAFW/Reports/image.jpg"
    global Summary_CurrentTest_Status

    if status.lower() == 'fail':
        global testcase_failcount
        testcase_failcount = testcase_failcount+1
        Summary_CurrentTest_Status = "FAILED"

    else:
        global testcase_passcount
        testcase_passcount = testcase_passcount+1

    stepdetails = addstepDetailsTemplate(stepname,request,response,expected,status,snapshot)
    fileAppend(testcaseHTMLPath, stepdetails)

# for selenium only 5 headings in the report
@dispatch(str,str,str,str,str)
def AddStepDetailsToTestcaseHTML(stepname,response,expected,status,snapshot):
    testcaseHTMLPath = ExcelDataAccess.CurrenttestcaseHTMLPath
    global Summary_CurrentTest_Status

    if status.lower() == 'fail':
        global testcase_failcount
        testcase_failcount = testcase_failcount+1
        Summary_CurrentTest_Status = "FAILED"

    else:
        global testcase_passcount
        testcase_passcount = testcase_passcount+1

    stepdetails = addstepDetailsInwebTemplate(stepname,response,expected,status,snapshot)
    fileAppend(testcaseHTMLPath, stepdetails)


def createTestcaseHTMLFooter(testcaseHTMLPath,SummaryHTMLFilePath,ScnearioName,TestcaseName,TestScenarioDescription):
    global testcase_passcount
    global testcase_failcount
    footerProperties = testcaseHTMLFooterProperties()
    fileAppend(testcaseHTMLPath, footerProperties)
    footerDetails = testcase_FooterTemplate(testcase_passcount,testcase_failcount)
    fileAppend(testcaseHTMLPath, footerDetails)

    testdetailsDetilas_in_Summary = Summary_TestCase_Details(ScnearioName,TestcaseName,testcaseHTMLPath,TestScenarioDescription,Summary_CurrentTest_Status)
    fileAppend(SummaryHTMLFilePath, testdetailsDetilas_in_Summary)

